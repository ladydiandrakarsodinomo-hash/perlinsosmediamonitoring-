-- Jalankan ini di Supabase SQL Editor satu kali

create table if not exists articles (
  id uuid primary key default gen_random_uuid(),
  source_id text,
  title text not null,
  url text unique not null,
  source_name text,
  published_at timestamptz,
  snippet text,
  sentiment text check (sentiment in ('positif', 'negatif', 'netral')),
  sentiment_reason text,
  keywords text[],
  category text,
  fetched_at timestamptz default now(),
  created_at timestamptz default now()
);

create index if not exists articles_published_at_idx on articles (published_at desc);
create index if not exists articles_sentiment_idx on articles (sentiment);
create index if not exists articles_fetched_at_idx on articles (fetched_at desc);

-- Enable Row Level Security tapi allow read untuk semua
alter table articles enable row level security;
create policy "Allow public read" on articles for select using (true);
create policy "Allow service role insert" on articles for insert with check (true);
create policy "Allow service role update" on articles for update using (true);

-- View untuk statistik harian
create or replace view daily_stats as
select
  date_trunc('day', published_at) as day,
  count(*) as total,
  count(*) filter (where sentiment = 'negatif') as negatif,
  count(*) filter (where sentiment = 'positif') as positif,
  count(*) filter (where sentiment = 'netral') as netral
from articles
where published_at >= now() - interval '30 days'
group by 1
order by 1 desc;
