import './globals.css'

export const metadata = {
  title: 'Bansos Media Monitor',
  description: 'Dashboard monitoring media online isu bantuan sosial Indonesia',
}

export default function RootLayout({ children }) {
  return (
    <html lang="id">
      <body className="bg-gray-50 text-gray-900 antialiased">{children}</body>
    </html>
  )
}
