'use client'
import { useState, useEffect, useCallback } from 'react'
import { RefreshCw, TrendingUp, TrendingDown, Minus, Search, AlertCircle, CheckCircle, Clock } from 'lucide-react'

const COLORS = { positif: '#1d9e75', negatif: '#e24b4a', netral: '#888780' }
const BG_COLORS = { positif: '#eaf3de', negatif: '#fcebeb', netral: '#f1efe8' }
const TEXT_COLORS = { positif: '#3b6d11', negatif: '#a32d2d', netral: '#5f5e5a' }

export default function Dashboard() {
  const [data, setData] = useState(null)
  const [loading, setLoading] = useState(true)
  const [filter, setFilter] = useState('semua')
  const [search, setSearch] = useState('')
  const [selectedArticle, setSelectedArticle] = useState(null)
  const [aiAnalysis, setAiAnalysis] = useState('')
  const [aiLoading, setAiLoading] = useState(false)
  const [question, setQuestion] = useState('')
  const [lastUpdate, setLastUpdate] = useState(null)

  const fetchData = useCallback(async () => {
    setLoading(true)
    try {
      const params = new URLSearchParams({ days: '7', limit: '60' })
      if (filter !== 'semua') params.set('sentiment', filter)
      if (search) params.set('q', search)
      const res = await fetch('/api/articles?' + params)
      const json = await res.json()
      setData(json)
      setLastUpdate(new Date())
    } catch (e) { console.error(e) }
    finally { setLoading(false) }
  }, [filter, search])

  useEffect(() => { fetchData() }, [fetchData])

  // Auto-refresh setiap 30 menit
  useEffect(() => {
    const interval = setInterval(fetchData, 30 * 60 * 1000)
    return () => clearInterval(interval)
  }, [fetchData])

  const analyzeArticle = async (article) => {
    setSelectedArticle(article)
    setAiAnalysis('')
    setAiLoading(true)
    try {
      const res = await fetch('/api/sentiment', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title: article.title, snippet: article.snippet })
      })
      const json = await res.json()
      setAiAnalysis(json.analysis)
    } catch (e) { setAiAnalysis('Gagal memuat analisis.') }
    finally { setAiLoading(false) }
  }

  const askQuestion = async () => {
    if (!question.trim() || !data) return
    setAiLoading(true)
    setAiAnalysis('')
    setSelectedArticle(null)
    try {
      const context = data.articles.slice(0, 20).map(a =>
        '- ' + a.title + ' (' + a.source_name + ', ' + a.sentiment + ')'
      ).join('\n')
      const res = await fetch('/api/sentiment', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ question, context })
      })
      const json = await res.json()
      setAiAnalysis(json.analysis)
    } catch (e) { setAiAnalysis('Gagal mendapat jawaban AI.') }
    finally { setAiLoading(false) }
    setQuestion('')
  }

  const stats = data?.stats || {}
  const articles = data?.articles || []
  const negPct = stats.total ? Math.round((stats.negatif / stats.total) * 100) : 0

  // Tren harian (group by day)
  const dailyMap = {}
  articles.forEach(a => {
    const day = a.published_at?.split('T')[0]
    if (!day) return
    if (!dailyMap[day]) dailyMap[day] = { total: 0, positif: 0, negatif: 0, netral: 0 }
    dailyMap[day].total++
    dailyMap[day][a.sentiment]++
  })
  const trendDays = Object.entries(dailyMap).sort().slice(-7)

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between flex-wrap gap-2">
          <div>
            <h1 className="text-lg font-semibold text-gray-900">Bansos Media Monitor</h1>
            <p className="text-xs text-gray-500">
              {lastUpdate ? 'Diperbarui ' + lastUpdate.toLocaleTimeString('id-ID') : 'Memuat...'}
              {' · '} Update otomatis 06:00–22:00 WIB
            </p>
          </div>
          <button onClick={fetchData} disabled={loading}
            className="flex items-center gap-1.5 text-sm px-3 py-1.5 border border-gray-200 rounded-lg hover:bg-gray-50 disabled:opacity-50 transition">
            <RefreshCw size={14} className={loading ? 'animate-spin' : ''} />
            Refresh
          </button>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-5">
        {/* Metrics */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-5">
          {[
            { label: 'Total Artikel (7 hari)', value: stats.total || 0, icon: null, delta: null },
            { label: 'Sentimen Negatif', value: negPct + '%', icon: negPct > 50 ? TrendingDown : TrendingUp, delta: negPct > 50 ? 'Waspadai eskalasi isu' : 'Terkendali', color: negPct > 50 ? 'text-red-600' : 'text-green-700' },
            { label: 'Sentimen Positif', value: (stats.total ? Math.round(stats.positif / stats.total * 100) : 0) + '%', icon: null },
            { label: 'Sumber Aktif', value: (data?.sources || []).length, icon: null },
          ].map((m, i) => (
            <div key={i} className="bg-white rounded-xl border border-gray-100 p-4">
              <p className="text-xs text-gray-500 mb-1">{m.label}</p>
              <p className="text-2xl font-medium text-gray-900">{m.value}</p>
              {m.delta && <p className={'text-xs mt-1 ' + (m.color || 'text-gray-500')}>{m.delta}</p>}
            </div>
          ))}
        </div>

        {/* Trend Bar Chart */}
        {trendDays.length > 0 && (
          <div className="bg-white rounded-xl border border-gray-100 p-4 mb-4">
            <p className="text-xs font-medium text-gray-400 uppercase tracking-wide mb-3">Tren 7 Hari</p>
            <div className="flex items-end gap-2 h-24">
              {trendDays.map(([day, counts]) => {
                const maxVal = Math.max(...trendDays.map(([, c]) => c.total), 1)
                const h = Math.max(4, Math.round((counts.total / maxVal) * 88))
                return (
                  <div key={day} className="flex-1 flex flex-col items-center gap-1">
                    <div className="w-full flex flex-col-reverse rounded overflow-hidden" style={{ height: h + 'px' }}>
                      <div style={{ height: (counts.positif / counts.total * 100) + '%', background: '#1d9e75' }} />
                      <div style={{ height: (counts.netral / counts.total * 100) + '%', background: '#888780' }} />
                      <div style={{ height: (counts.negatif / counts.total * 100) + '%', background: '#e24b4a' }} />
                    </div>
                    <span className="text-xs text-gray-400" style={{ fontSize: 10 }}>
                      {new Date(day).toLocaleDateString('id-ID', { day: 'numeric', month: 'short' })}
                    </span>
                  </div>
                )
              })}
            </div>
            <div className="flex gap-4 mt-2">
              {['negatif', 'netral', 'positif'].map(s => (
                <span key={s} className="flex items-center gap-1 text-xs text-gray-500">
                  <span className="w-2 h-2 rounded-sm inline-block" style={{ background: COLORS[s] }} />
                  {s.charAt(0).toUpperCase() + s.slice(1)}
                </span>
              ))}
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {/* Left: News list */}
          <div className="lg:col-span-2 space-y-3">
            {/* Filters */}
            <div className="flex flex-wrap gap-2 items-center">
              <div className="relative flex-1 min-w-40">
                <Search size={14} className="absolute left-3 top-2.5 text-gray-400" />
                <input value={search} onChange={e => setSearch(e.target.value)}
                  placeholder="Cari berita bansos..."
                  className="w-full pl-8 pr-3 py-2 text-sm border border-gray-200 rounded-lg bg-white focus:outline-none focus:border-blue-400" />
              </div>
              {['semua', 'negatif', 'positif', 'netral'].map(f => (
                <button key={f} onClick={() => setFilter(f)}
                  className={'text-sm px-3 py-1.5 rounded-lg border transition ' +
                    (filter === f ? 'bg-blue-600 text-white border-blue-600' : 'bg-white text-gray-600 border-gray-200 hover:bg-gray-50')}>
                  {f.charAt(0).toUpperCase() + f.slice(1)}
                </button>
              ))}
            </div>

            {loading ? (
              <div className="text-center py-12 text-gray-400 text-sm">Memuat artikel...</div>
            ) : articles.length === 0 ? (
              <div className="text-center py-12 text-gray-400 text-sm">Tidak ada artikel ditemukan.</div>
            ) : (
              <div className="space-y-2">
                {articles.map(a => (
                  <div key={a.id} onClick={() => analyzeArticle(a)}
                    className={'bg-white border rounded-xl p-3.5 cursor-pointer transition ' +
                      (selectedArticle?.id === a.id ? 'border-blue-400 ring-1 ring-blue-200' : 'border-gray-100 hover:border-gray-300')}>
                    <div className="flex items-start justify-between gap-2 mb-1.5">
                      <p className="text-sm font-medium text-gray-900 leading-snug">{a.title}</p>
                      <span className="text-xs font-medium px-2 py-0.5 rounded-full flex-shrink-0"
                        style={{ background: BG_COLORS[a.sentiment], color: TEXT_COLORS[a.sentiment] }}>
                        {a.sentiment}
                      </span>
                    </div>
                    <div className="flex gap-3 text-xs text-gray-400 flex-wrap">
                      <span>{a.source_name}</span>
                      <span>{a.published_at ? new Date(a.published_at).toLocaleDateString('id-ID', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }) : ''}</span>
                      {a.category && <span className="capitalize">{a.category}</span>}
                    </div>
                    {a.snippet && <p className="text-xs text-gray-500 mt-1.5 line-clamp-2">{a.snippet}</p>}
                    {(a.keywords || []).length > 0 && (
                      <div className="flex flex-wrap gap-1 mt-2">
                        {a.keywords.slice(0, 4).map(kw => (
                          <span key={kw} className="text-xs px-1.5 py-0.5 bg-blue-50 text-blue-700 rounded">{kw}</span>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Right sidebar */}
          <div className="space-y-4">
            {/* AI Panel */}
            <div className="bg-white border border-gray-100 rounded-xl p-4">
              <p className="text-xs font-medium text-gray-400 uppercase tracking-wide mb-3">Analisis AI</p>
              <div className="min-h-24 mb-3">
                {aiLoading ? (
                  <p className="text-sm text-gray-400 italic">AI sedang menganalisis...</p>
                ) : aiAnalysis ? (
                  <p className="text-sm text-gray-700 whitespace-pre-wrap leading-relaxed">{aiAnalysis}</p>
                ) : (
                  <p className="text-sm text-gray-400">Klik artikel untuk analisis otomatis, atau ajukan pertanyaan di bawah.</p>
                )}
              </div>
              <div className="flex gap-2">
                <input value={question} onChange={e => setQuestion(e.target.value)}
                  onKeyDown={e => e.key === 'Enter' && askQuestion()}
                  placeholder='Tanya AI tentang bansos...'
                  className="flex-1 text-sm px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:border-blue-400" />
                <button onClick={askQuestion} disabled={aiLoading}
                  className="text-sm px-3 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50">↗</button>
              </div>
            </div>

            {/* Sources */}
            {(data?.sources || []).length > 0 && (
              <div className="bg-white border border-gray-100 rounded-xl p-4">
                <p className="text-xs font-medium text-gray-400 uppercase tracking-wide mb-3">Sumber Berita</p>
                <div className="space-y-2">
                  {(data.sources || []).slice(0, 8).map(s => {
                    const max = data.sources[0].count
                    return (
                      <div key={s.name} className="flex items-center gap-2">
                        <span className="text-xs text-gray-600 w-24 truncate">{s.name}</span>
                        <div className="flex-1 h-1.5 bg-gray-100 rounded-full overflow-hidden">
                          <div className="h-full bg-blue-500 rounded-full" style={{ width: Math.round(s.count / max * 100) + '%' }} />
                        </div>
                        <span className="text-xs text-gray-400 w-5 text-right">{s.count}</span>
                      </div>
                    )
                  })}
                </div>
              </div>
            )}

            {/* Keywords */}
            {(data?.topKeywords || []).length > 0 && (
              <div className="bg-white border border-gray-100 rounded-xl p-4">
                <p className="text-xs font-medium text-gray-400 uppercase tracking-wide mb-3">Kata Kunci Trending</p>
                <div className="flex flex-wrap gap-1.5">
                  {(data.topKeywords || []).map(kw => (
                    <button key={kw.word} onClick={() => setSearch(kw.word)}
                      className="text-xs px-2 py-1 bg-gray-50 hover:bg-blue-50 text-gray-600 hover:text-blue-700 border border-gray-100 rounded-md transition">
                      {kw.word} <span className="text-gray-400">{kw.count}</span>
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
