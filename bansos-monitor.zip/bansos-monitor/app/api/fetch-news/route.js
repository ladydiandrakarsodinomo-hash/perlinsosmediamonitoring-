import { NextResponse } from 'next/server'
import { fetchGoogleNews, fetchNewsAPI } from '@/lib/news-fetcher'
import { analyzeBatch } from '@/lib/sentiment-analyzer'
import { supabaseAdmin } from '@/lib/supabase'

// Jam operasional WIB: 06:00 - 22:00
function isOperationalHour() {
  const now = new Date()
  const wibHour = (now.getUTCHours() + 7) % 24
  return wibHour >= 6 && wibHour < 22
}

export async function POST(req) {
  const authHeader = req.headers.get('authorization')
  if (authHeader !== 'Bearer ' + process.env.CRON_SECRET) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  const body = await req.json().catch(() => ({}))
  if (!isOperationalHour() && !body.force) {
    return NextResponse.json({ skipped: true, message: 'Di luar jam operasional (06:00-22:00 WIB)' })
  }

  try {
    const [googleArticles, newsApiArticles] = await Promise.allSettled([
      fetchGoogleNews(),
      fetchNewsAPI(),
    ])

    const allRaw = [
      ...(googleArticles.status === 'fulfilled' ? googleArticles.value : []),
      ...(newsApiArticles.status === 'fulfilled' ? newsApiArticles.value : []),
    ]

    if (!allRaw.length) return NextResponse.json({ inserted: 0, message: 'Tidak ada artikel baru' })

    const urls = allRaw.map(a => a.url)
    const { data: existing } = await supabaseAdmin.from('articles').select('url').in('url', urls)
    const existingUrls = new Set((existing || []).map(e => e.url))
    const newArticles = allRaw.filter(a => !existingUrls.has(a.url))

    if (!newArticles.length) return NextResponse.json({ inserted: 0, message: 'Semua artikel sudah ada' })

    const analyzed = await analyzeBatch(newArticles)
    const { data, error } = await supabaseAdmin.from('articles').insert(analyzed).select('id')

    if (error) throw error
    return NextResponse.json({ inserted: data.length })
  } catch (err) {
    return NextResponse.json({ error: err.message }, { status: 500 })
  }
}

export async function GET() {
  const wibHour = (new Date().getUTCHours() + 7) % 24
  const { data } = await supabaseAdmin
    .from('articles').select('fetched_at').order('fetched_at', { ascending: false }).limit(1)
  return NextResponse.json({ operational: wibHour >= 6 && wibHour < 22, last_fetch: data?.[0]?.fetched_at || null })
}
