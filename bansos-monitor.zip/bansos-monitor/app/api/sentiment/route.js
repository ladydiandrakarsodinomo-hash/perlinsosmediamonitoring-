import { NextResponse } from 'next/server'
import Anthropic from '@anthropic-ai/sdk'

const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY })

export async function POST(req) {
  const { title, snippet, question, context } = await req.json()

  let prompt
  if (question) {
    prompt = 'Kamu adalah analis media monitoring bansos Indonesia. Jawab pertanyaan berikut berdasarkan data yang diberikan dalam Bahasa Indonesia.\n\nData berita terkini:\n' + context + '\n\nPertanyaan: ' + question
  } else {
    prompt = 'Kamu adalah analis media monitoring bansos Indonesia. Analisis artikel berikut dalam format:\n\n[RINGKASAN] 2 kalimat\n[SENTIMEN & ALASAN] mengapa positif/negatif/netral\n[ISU UTAMA] apa masalah atau prestasi yang disorot\n[REKOMENDASI] saran kebijakan singkat\n\nJudul: ' + title + '\nIsi: ' + (snippet || '(tidak ada)')
  }

  const msg = await anthropic.messages.create({
    model: 'claude-haiku-4-5-20251001',
    max_tokens: 600,
    messages: [{ role: 'user', content: prompt }]
  })

  return NextResponse.json({ analysis: msg.content[0].text })
}
