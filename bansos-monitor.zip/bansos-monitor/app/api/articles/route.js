import { NextResponse } from 'next/server'
import { supabase } from '@/lib/supabase'

export async function GET(req) {
  const { searchParams } = new URL(req.url)
  const sentiment = searchParams.get('sentiment')
  const search = searchParams.get('q')
  const days = parseInt(searchParams.get('days') || '7')
  const limit = parseInt(searchParams.get('limit') || '50')

  const since = new Date()
  since.setDate(since.getDate() - days)

  let query = supabase
    .from('articles')
    .select('*')
    .gte('published_at', since.toISOString())
    .order('published_at', { ascending: false })
    .limit(limit)

  if (sentiment && sentiment !== 'semua') query = query.eq('sentiment', sentiment)
  if (search) query = query.ilike('title', '%' + search + '%')

  const { data, error } = await query
  if (error) return NextResponse.json({ error: error.message }, { status: 500 })

  // Hitung statistik
  const stats = {
    total: data.length,
    positif: data.filter(a => a.sentiment === 'positif').length,
    negatif: data.filter(a => a.sentiment === 'negatif').length,
    netral: data.filter(a => a.sentiment === 'netral').length,
  }

  // Top keywords
  const kwCount = {}
  data.forEach(a => (a.keywords || []).forEach(kw => { kwCount[kw] = (kwCount[kw] || 0) + 1 }))
  const topKeywords = Object.entries(kwCount)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 20)
    .map(([word, count]) => ({ word, count }))

  // Sumber terpopuler
  const srcCount = {}
  data.forEach(a => { srcCount[a.source_name] = (srcCount[a.source_name] || 0) + 1 })
  const sources = Object.entries(srcCount)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 10)
    .map(([name, count]) => ({ name, count }))

  return NextResponse.json({ articles: data, stats, topKeywords, sources })
}
