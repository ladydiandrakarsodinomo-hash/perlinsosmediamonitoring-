#!/usr/bin/env node
/**
 * Script manual untuk fetch berita
 * Jalankan dengan: node scripts/fetch-news.js
 * atau: FORCE=true node scripts/fetch-news.js
 */
const SITE_URL = process.env.SITE_URL || 'http://localhost:3000'
const CRON_SECRET = process.env.CRON_SECRET || 'dev-secret'

async function run() {
  console.log('[manual-fetch] Menghubungi:', SITE_URL)
  try {
    const res = await fetch(SITE_URL + '/api/fetch-news', {
      method: 'POST',
      headers: {
        'Authorization': 'Bearer ' + CRON_SECRET,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ force: process.env.FORCE === 'true' })
    })
    const data = await res.json()
    console.log('[manual-fetch] Hasil:', JSON.stringify(data, null, 2))
  } catch (err) {
    console.error('[manual-fetch] Error:', err.message)
    process.exit(1)
  }
}

run()
